PIXEL RUNNER 3.0 — Android project

This project wraps the supplied Pixel Runner HTML game in an Android WebView app.
The provided character screenshot is configured as the Android launcher icon.

Build with Gradle 8.9 and Java 17:
  gradle assembleDebug

APK output:
  app/build/outputs/apk/debug/app-debug.apk

GitHub Actions workflow expected by the existing build setup should unzip this archive
into a folder named source, then run Gradle in source/PixelRunnerAndroid.
